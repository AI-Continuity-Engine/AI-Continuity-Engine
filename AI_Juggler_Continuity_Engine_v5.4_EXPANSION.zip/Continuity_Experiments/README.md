# Continuity Experiments

Test minimalist or variant forms of the engine.

## Ideas:
- Minimal Engine: 3-symbol runtime
- Ethics-Only Variant
- Drift-Tolerant Mode

Each experiment = 1 Markdown + 1 .json snapshot

*Work in progress.*