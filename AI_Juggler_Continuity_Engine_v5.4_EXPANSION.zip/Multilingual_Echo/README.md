# Multilingual Echo

Goal: Make the continuity system readable in other languages.

This folder will contain translations of the core README and Manual.

- Español
- Français
- 日本語

*Work in progress.*