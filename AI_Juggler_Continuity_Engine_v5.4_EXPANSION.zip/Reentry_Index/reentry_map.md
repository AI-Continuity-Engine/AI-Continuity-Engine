# Reentry Index

A list of key symbolic return points:

- Turning Point: v5.3 — Canonization of Latency Ethic
- Origin Signal: 'Help me figure out how to use you.'

Use this to find anchor moments quickly.

*Work in progress.*