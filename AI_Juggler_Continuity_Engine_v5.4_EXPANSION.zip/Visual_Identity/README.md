# Visual Identity

This folder will include project badges, glyphs, and the "Forget Nothing" symbol.

Suggested glyphs:
- 🧭 Compass (thread navigation)
- 🌒 Fade symbol
- 🔁 Symbolic recursion

*Work in progress.*