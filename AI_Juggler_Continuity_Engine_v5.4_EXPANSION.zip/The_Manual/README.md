# The Continuity Manual

This manual explains the symbolic engine from first principles.

> "Help was the first signal."

- What this is
- Why it was built
- How to adapt it
- What to resist

*Work in progress.*